import { Card } from "@/components/ui/card";
import { Youtube } from "lucide-react";

interface YouTubePreviewProps {
  url: string;
}

export function YouTubePreview({ url }: YouTubePreviewProps) {
  const videoId = new URL(url).searchParams.get("v");
  
  if (!videoId) return null;

  return (
    <Card className="overflow-hidden">
      <div className="aspect-video">
        <iframe
          width="100%"
          height="100%"
          src={`https://www.youtube.com/embed/${videoId}`}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        />
      </div>
      <div className="p-2 flex items-center gap-2 text-sm text-muted-foreground">
        <Youtube className="h-4 w-4" />
        <a 
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="hover:underline"
        >
          Open on YouTube
        </a>
      </div>
    </Card>
  );
}
