import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Send, Loader2, ChevronUp, ChevronDown } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { ChatSuggestions } from "./ChatSuggestions";
import { Message } from "@shared/schema";

interface ChatInputProps {
  messages: Message[];
}

export function ChatInput({ messages }: ChatInputProps) {
  const [input, setInput] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(true);
const toggleSuggestions = () => setShowSuggestions(prev => !prev);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const mutation = useMutation({
    mutationFn: async (content: string) => {
      const response = await apiRequest("POST", "/api/messages", {
        role: "user",
        content
      });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      setInput("");
      setShowSuggestions(true);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    setShowSuggestions(false);
    mutation.mutate(input);
  };

  const handleSuggestionSelect = (suggestion: string) => {
    setInput(suggestion);
    setShowSuggestions(false);
    mutation.mutate(suggestion);
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <div className={cn(
          "transition-all duration-300 ease-in-out",
          showSuggestions ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-4 pointer-events-none h-0"
        )}>
          {messages.length > 0 && (
            <ChatSuggestions
              messages={messages}
              onSelect={handleSuggestionSelect}
              className="mb-4"
            />
          )}
        </div>
        <Button
          type="button"
          size="icon"
          variant="ghost"
          onClick={toggleSuggestions}
          className="absolute -top-1 right-2 z-10 w-6 h-6 hover:bg-accent/50"
        >
          {showSuggestions ? (
            <ChevronUp className="h-4 w-4" />
          ) : (
            <ChevronDown className="h-4 w-4" />
          )}
        </Button>
      </div>
      <form onSubmit={handleSubmit} className="relative group">
        <Input
          value={input}
          onChange={(e) => {
            setInput(e.target.value);
            setShowSuggestions(false);
          }}
          onFocus={() => setShowSuggestions(true)}
          placeholder="Ask Krishna AI anything..."
          className={cn(
            "w-full pr-24 bg-background/60 backdrop-blur-sm transition-all duration-300",
            "focus:ring-2 focus:ring-primary/20 focus:border-primary/30",
            "group-hover:border-primary/30 group-hover:shadow-md",
            "placeholder:text-muted-foreground/70"
          )}
          disabled={mutation.isPending}
        />
        <div className="absolute right-1 top-1 bottom-1">
          <Button
            type="submit"
            size="sm"
            disabled={mutation.isPending || !input.trim()}
            className={cn(
              "px-4 h-full transition-all duration-300",
              "bg-gradient-to-r from-indigo-600 to-purple-600",
              "hover:from-indigo-500 hover:to-purple-500",
              "disabled:from-gray-400 disabled:to-gray-300",
              "text-white shadow-md hover:shadow-lg",
              mutation.isPending && "opacity-70"
            )}
          >
            {mutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Send className="h-4 w-4" />
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}