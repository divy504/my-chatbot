import { Message, InsertMessage, LearningPath, InsertLearningPath } from "@shared/schema";

export interface IStorage {
  getMessages(): Promise<Message[]>;
  addMessage(message: InsertMessage): Promise<Message>;
  getLearningPath(topic: string): Promise<LearningPath | undefined>;
  createLearningPath(path: InsertLearningPath): Promise<LearningPath>;
  updateLearningProgress(id: number, progress: number): Promise<LearningPath>;
}

export class MemStorage implements IStorage {
  private messages: Map<number, Message>;
  private learningPaths: Map<number, LearningPath>;
  private currentMessageId: number;
  private currentPathId: number;

  constructor() {
    this.messages = new Map();
    this.learningPaths = new Map();
    this.currentMessageId = 1;
    this.currentPathId = 1;
  }

  async getMessages(): Promise<Message[]> {
    return Array.from(this.messages.values());
  }

  async addMessage(message: InsertMessage): Promise<Message> {
    const id = this.currentMessageId++;
    const newMessage = {
      ...message,
      id,
      timestamp: new Date()
    };
    this.messages.set(id, newMessage);
    return newMessage;
  }

  async getLearningPath(topic: string): Promise<LearningPath | undefined> {
    return Array.from(this.learningPaths.values()).find(
      path => path.topic === topic
    );
  }

  async createLearningPath(path: InsertLearningPath): Promise<LearningPath> {
    const id = this.currentPathId++;
    const newPath = { ...path, id };
    this.learningPaths.set(id, newPath);
    return newPath;
  }

  async updateLearningProgress(id: number, progress: number): Promise<LearningPath> {
    const path = this.learningPaths.get(id);
    if (!path) throw new Error("Learning path not found");
    
    const updatedPath = { ...path, progress };
    this.learningPaths.set(id, updatedPath);
    return updatedPath;
  }
}

export const storage = new MemStorage();
