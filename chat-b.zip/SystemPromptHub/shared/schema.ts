import { pgTable, text, serial, integer, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  role: text("role").notNull(), // 'user' | 'assistant'
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  youtubeUrl: text("youtube_url"),
  metadata: jsonb("metadata")
});

export const learningPaths = pgTable("learning_paths", {
  id: serial("id").primaryKey(),
  topic: text("topic").notNull(),
  mode: text("mode").notNull(), // 'chapter' | 'course'
  progress: integer("progress").notNull().default(0),
  content: jsonb("content").notNull() // Array of chapters/lessons
});

export const insertMessageSchema = createInsertSchema(messages).omit({ 
  id: true,
  timestamp: true 
});

export const insertLearningPathSchema = createInsertSchema(learningPaths).omit({
  id: true
});

export type Message = typeof messages.$inferSelect;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type LearningPath = typeof learningPaths.$inferSelect;
export type InsertLearningPath = z.infer<typeof insertLearningPathSchema>;
