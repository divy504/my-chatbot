import { useState } from "react";
import { Card, CardHeader, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { LearningPath as LearningPathType } from "@shared/schema";

interface LearningPathProps {
  topic: string;
}

export function LearningPath({ topic }: LearningPathProps) {
  const [mode, setMode] = useState<"chapter" | "course" | null>(null);

  const { data: path, isLoading } = useQuery<LearningPathType>({
    queryKey: ["/api/learning-path", topic],
  });

  const createPath = useMutation({
    mutationFn: async () => {
      if (!mode) return;
      const response = await apiRequest("POST", "/api/learning-path", {
        topic,
        mode,
        content: generateContent(topic, mode)
      });
      return response.json();
    }
  });

  if (isLoading) return <div>Loading...</div>;

  if (!path && !mode) {
    return (
      <Card>
        <CardHeader className="text-lg font-semibold">
          How would you like to learn {topic}?
        </CardHeader>
        <CardContent className="flex gap-4">
          <Button onClick={() => setMode("chapter")}>
            Chapter-wise Learning
          </Button>
          <Button onClick={() => setMode("course")}>
            Course Mode
          </Button>
        </CardContent>
      </Card>
    );
  }

  const currentPath = path || createPath.data;
  if (!currentPath) return null;

  return (
    <Card>
      <CardHeader className="text-lg font-semibold">
        {currentPath.topic} - {currentPath.mode === "chapter" ? "Chapter" : "Course"} Mode
      </CardHeader>
      <CardContent>
        <Progress value={currentPath.progress} className="mb-4" />
        <div className="space-y-2">
          {Array.isArray(currentPath.content) && currentPath.content.map((item, i) => (
            <div key={i} className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${i <= currentPath.progress ? "bg-primary" : "bg-gray-200"}`} />
              <span>{item}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function generateContent(topic: string, mode: "chapter" | "course"): string[] {
  // This would ideally come from the AI but for now we'll use placeholder content
  return mode === "chapter" 
    ? [`Introduction to ${topic}`, "Basic Concepts", "Advanced Topics"]
    : [`${topic} 101`, `${topic} 201`, `${topic} 301`, "Final Project"];
}
