
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Message } from "@shared/schema";
import { Lightbulb, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { apiRequest } from "@/lib/queryClient";

interface ChatSuggestionsProps {
  messages: Message[];
  onSelect: (suggestion: string) => void;
  className?: string;
}

export function ChatSuggestions({ messages, onSelect, className }: ChatSuggestionsProps) {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const lastMessage = messages[messages.length - 1];

  useEffect(() => {
    const fetchSuggestions = async () => {
      try {
        setLoading(true);
        const response = await apiRequest("POST", "/api/suggestions", {
          lastMessage: lastMessage?.content
        });
        const data = await response.json();
        setSuggestions(data.suggestions);
      } catch (error) {
        console.error("Failed to fetch suggestions:", error);
        setSuggestions([
          "Tell me more about that",
          "What else should I know?",
          "Can you explain further?"
        ]);
      } finally {
        setLoading(false);
      }
    };

    fetchSuggestions();
  }, [lastMessage?.content]);

  if (!suggestions.length && !loading) return null;

  return (
    <Card className={cn(
      "p-2 animate-in slide-in-from-bottom-1",
      "bg-background/60 backdrop-blur-sm",
      className
    )}>
      <div className="flex items-center gap-2 px-2 mb-2 text-sm text-muted-foreground">
        <Lightbulb className="h-4 w-4" />
        <span>Suggested questions</span>
      </div>
      <div className="flex flex-wrap gap-2">
        {loading ? (
          <div className="w-full flex justify-center p-2">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        ) : suggestions.map((suggestion, index) => (
          <Button
            key={index}
            variant="outline"
            size="sm"
            className="text-sm bg-background/60 hover:bg-background"
            onClick={() => onSelect(suggestion)}
          >
            {suggestion}
          </Button>
        ))}
      </div>
    </Card>
  );
}
