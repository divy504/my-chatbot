import type { Message } from "@shared/schema";

const CHAT_HISTORY_KEY = "chat_history";
const MAX_STORED_MESSAGES = 100; // Limit stored messages to prevent storage issues

export function saveMessages(messages: Message[], chatId?: string) {
  try {
    if (messages && messages.length > 0) {
      // Only store the most recent messages
      const recentMessages = messages.slice(-MAX_STORED_MESSAGES);
      localStorage.setItem(
        chatId ? `chat_${chatId}` : CHAT_HISTORY_KEY,
        JSON.stringify(recentMessages)
      );
    }
  } catch (e) {
    console.error("Failed to save messages:", e);
  }
}

export function loadMessages(chatId?: string): Message[] {
  try {
    const stored = localStorage.getItem(chatId ? `chat_${chatId}` : CHAT_HISTORY_KEY);
    if (!stored) return [];
    const messages = JSON.parse(stored);
    return Array.isArray(messages) ? messages : [];
  } catch (e) {
    console.error("Failed to load messages:", e);
    return [];
  }
}

export function clearMessages() {
  try {
    localStorage.removeItem(CHAT_HISTORY_KEY);
  } catch (e) {
    console.error("Failed to clear messages:", e);
  }
  return [];
}

export function addToHistory(chatId: string, title: string) {
  try {
    const history = getHistory();
    // Truncate long titles
    const shortTitle = title.length > 50 ? title.substring(0, 47) + "..." : title;
    const newEntry = { id: chatId, title: shortTitle, timestamp: new Date().toISOString() };
    // Remove any existing chat with same ID
    const filteredHistory = history.filter(chat => chat.id !== chatId);
    // Add new chat at the beginning and keep last 10 chats
    const updatedHistory = [newEntry, ...filteredHistory].slice(0, 10);
    localStorage.setItem('chat_history_list', JSON.stringify(updatedHistory));
  } catch (e) {
    console.error("Failed to add to history:", e);
  }
}

export function getHistory() {
  try {
    const stored = localStorage.getItem('chat_history_list');
    if (!stored) return [];
    const history = JSON.parse(stored);
    return Array.isArray(history) ? history : [];
  } catch (e) {
    console.error("Failed to get history:", e);
    return [];
  }
}

export function clearHistory() {
  try {
    localStorage.removeItem('chat_history_list');
    localStorage.removeItem(CHAT_HISTORY_KEY); // Also clear current messages
  } catch (e) {
    console.error("Failed to clear history:", e);
  }
}