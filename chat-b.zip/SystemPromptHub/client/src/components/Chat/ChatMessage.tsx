import { Message } from "@shared/schema";
import { Card } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { MessageCircle, Sparkles } from "lucide-react";
import { YouTubePreview } from "../YouTube/YouTubePreview";
import ReactMarkdown from 'react-markdown';
import { cn } from "@/lib/utils";

interface ChatMessageProps {
  message: Message;
}

export function ChatMessage({ message }: ChatMessageProps) {
  const isUser = message.role === "user";

  return (
    <div className={cn(
      "flex gap-4 items-start px-2 mb-4",
      "animate-in fade-in-0 slide-in-from-bottom-3 duration-500",
      isUser ? "flex-row-reverse" : "flex-row"
    )}>
      <Avatar className={cn(
        "h-12 w-12 ring-2 ring-offset-2 transition-all duration-300",
        isUser 
          ? "ring-primary/30 bg-gradient-to-br from-primary to-primary/70" 
          : "ring-indigo-500/30 bg-gradient-to-br from-indigo-600 to-purple-600"
      )}>
        <AvatarFallback className="flex items-center justify-center bg-transparent">
          {isUser ? (
            <MessageCircle className="h-6 w-6 text-primary-foreground" />
          ) : (
            <Sparkles className="h-6 w-6 text-white" />
          )}
        </AvatarFallback>
      </Avatar>

      <Card className={cn(
        "p-4 max-w-[85%] shadow-lg transition-all duration-300",
        "hover:shadow-xl transform hover:-translate-y-0.5",
        isUser 
          ? "bg-white text-black dark:bg-white dark:text-black" 
          : "bg-gradient-to-r from-indigo-500/20 to-purple-500/15 dark:from-indigo-500/40 dark:to-purple-500/35 hover:from-indigo-500/25 hover:to-purple-500/20 dark:hover:from-indigo-500/45 dark:hover:to-purple-500/40"
      )}>
        <ReactMarkdown className={cn(
          "prose max-w-none text-sm leading-relaxed",
          isUser ? "!text-black" : "prose-neutral dark:prose-invert",
          "prose-p:my-1 last:prose-p:mb-0 first:prose-p:mt-0",
          "prose-pre:bg-muted/50 prose-pre:p-4 prose-pre:rounded-lg",
          "prose-a:text-primary prose-a:no-underline hover:prose-a:underline"
        )}>
          {message.content}
        </ReactMarkdown>

        {message.youtubeUrl && (
          <div className="mt-4 animate-in fade-in slide-in-from-bottom-2">
            <YouTubePreview url={message.youtubeUrl} />
          </div>
        )}
      </Card>
    </div>
  );
}