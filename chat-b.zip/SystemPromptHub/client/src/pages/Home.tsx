import { useQuery } from "@tanstack/react-query";
import { Message } from "@shared/schema";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ChatMessage } from "@/components/Chat/ChatMessage";
import { ChatInput } from "@/components/Chat/ChatInput";
import { saveMessages, loadMessages, clearMessages, getHistory, clearHistory, addToHistory } from "@/lib/storage";
import { useEffect, useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Menu, RocketIcon, History, Trash2, Plus, Sparkles } from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";
import { nanoid } from "nanoid";

export default function Home() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const [currentChatId] = useState(() => nanoid());

  const { data: messages = [], isLoading, refetch } = useQuery<Message[]>({
    queryKey: ["/api/messages"],
    initialData: loadMessages()
  });

  const chatHistory = getHistory();

  useEffect(() => {
    // Update history with first message as title
    if (messages.length > 0 && messages[0].role === 'user') {
      addToHistory(currentChatId, messages[0].content);
    }

    saveMessages(messages);
    // Scroll to bottom on new messages
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, currentChatId]);

  const startNewChat = async () => {
    try {
      await clearMessages();
      await refetch();
      setOpen(false);
      window.location.reload(); // Force a complete refresh to reset all states
      toast({
        title: "Success",
        description: "Started a new chat",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to start new chat",
        variant: "destructive"
      });
    }
  };

  const handleClearHistory = async () => {
    try {
      await clearHistory();
      await clearMessages();
      await refetch();
      setOpen(false);
      window.location.reload(); // Force a complete refresh
      toast({
        title: "Success",
        description: "Chat history cleared",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to clear history",
        variant: "destructive"
      });
    }
  };

  const loadChatFromHistory = async (chatId: string) => {
    try {
      const savedMessages = loadMessages(chatId);
      await refetch();
      if (savedMessages.length > 0) {
        messages.splice(0, messages.length, ...savedMessages);
      }
      setOpen(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load chat history",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="h-[100dvh] flex flex-col bg-gradient-to-b from-background to-background/95">
      <header className="border-b bg-card/50 backdrop-blur-sm shadow-sm">
        <div className="container max-w-4xl mx-auto py-3 px-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Sheet open={open} onOpenChange={setOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="shrink-0 hover:bg-primary/10">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[300px] sm:w-[400px]">
                  <SheetHeader className="space-y-4 pb-4 border-b">
                    <SheetTitle className="text-lg font-bold flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-primary" />
                      Chat History
                    </SheetTitle>
                    <Button 
                      variant="destructive" 
                      className="w-full justify-start gap-2"
                      onClick={handleClearHistory}
                    >
                      <Trash2 className="h-4 w-4" />
                      Clear History
                    </Button>
                  </SheetHeader>
                  <div className="py-4 space-y-2">
                    {chatHistory.map((chat) => (
                      <Button 
                        key={chat.id}
                        variant="outline" 
                        className="w-full justify-start gap-2 text-left group hover:border-primary/30"
                        onClick={() => loadChatFromHistory(chat.id)}
                      >
                        <History className="h-4 w-4 shrink-0 group-hover:text-primary" />
                        <span className="truncate">{chat.title}</span>
                      </Button>
                    ))}
                  </div>
                </SheetContent>
              </Sheet>
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-lg bg-gradient-to-br from-indigo-500/20 to-purple-500/20">
                  <Sparkles className="h-5 w-5 text-indigo-600" />
                </div>
                <div>
                  <h1 className="font-bold text-lg bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                    Krishna AI
                  </h1>
                  <p className="text-xs text-muted-foreground">Divine wisdom at your service</p>
                </div>
              </div>
            </div>
            <Button 
              onClick={startNewChat}
              variant="outline" 
              size="sm"
              className="gap-2 hover:border-primary/30 hover:bg-primary/5"
            >
              <Plus className="h-4 w-4" />
              New Chat
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 min-h-0 container max-w-4xl mx-auto px-4">
        <ScrollArea className="h-full pr-4">
          {messages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center gap-4 text-muted-foreground">
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20 flex items-center justify-center animate-pulse">
                <Sparkles className="h-10 w-10 text-indigo-600" />
              </div>
              <p className="text-center max-w-[15rem] text-sm">
                Begin your journey of enlightenment with Krishna AI...
              </p>
            </div>
          ) : (
            <div className="space-y-6 py-6">
              {messages.map((message) => (
                <ChatMessage key={message.id} message={message} />
              ))}
              <div ref={scrollRef} />
            </div>
          )}
        </ScrollArea>
      </main>

      <footer className="border-t bg-background/50 backdrop-blur-sm shadow-[0_-1px_3px_rgba(0,0,0,0.05)]">
        <div className="container max-w-4xl mx-auto p-4">
          <ChatInput messages={messages} />
        </div>
      </footer>
    </div>
  );
}