import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertMessageSchema, insertLearningPathSchema } from "@shared/schema";

async function getGeminiResponse(content: string) {
  try {
    const { GoogleGenerativeAI } = await import("@google/generative-ai");
    if (!process.env.GOOGLE_AI_API_KEY) {
      throw new Error("Gemini API key not configured");
    }

    const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_API_KEY);
    const model = genAI.getGenerativeModel({ model: "gemini-pro" });

    const result = await model.generateContent(content);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error('Gemini AI Error:', error);
    throw error;
  }
}

export async function registerRoutes(app: Express) {
  app.get("/api/messages", async (req, res) => {
    const messages = await storage.getMessages();
    res.json(messages);
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const result = insertMessageSchema.safeParse(req.body);
      if (!result.success) {
        return res.status(400).json({ error: result.error });
      }

      const userMessage = await storage.addMessage(result.data);

      try {
        const aiContent = await getGeminiResponse(userMessage.content);
        const assistantMessage = await storage.addMessage({
          role: "assistant",
          content: aiContent
        });

        res.json({
          userMessage,
          assistantMessage
        });
      } catch (error) {
        console.error('AI Response Error:', error);
        const fallbackMessage = await storage.addMessage({
          role: "assistant",
          content: "I apologize, but I'm having trouble processing your request right now. Please try again later."
        });

        res.json({
          userMessage,
          assistantMessage: fallbackMessage
        });
      }
    } catch (error) {
      console.error('Request Error:', error);
      res.status(500).json({ 
        error: "Failed to process message",
        details: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/learning-path/:topic", async (req, res) => {
    const path = await storage.getLearningPath(req.params.topic);
    if (!path) return res.status(404).json({ error: "Learning path not found" });
    res.json(path);
  });

  app.post("/api/learning-path", async (req, res) => {
    const result = insertLearningPathSchema.safeParse(req.body);
    if (!result.success) {
      return res.status(400).json({ error: result.error });
    }
    const path = await storage.createLearningPath(result.data);
    res.json(path);
  });

  app.post("/api/suggestions", async (req, res) => {
    try {
      const { lastMessage } = req.body;
      const prompt = lastMessage ? 
        `Based on this message: "${lastMessage}", suggest 3 relevant follow-up questions. Respond with just the questions separated by |` :
        "Suggest 3 general questions to start a conversation about spirituality and wisdom. Respond with just the questions separated by |";
      
      const suggestions = await getGeminiResponse(prompt);
      res.json({ suggestions: suggestions.split('|').map(s => s.trim()) });
    } catch (error) {
      console.error('Suggestions Error:', error);
      res.status(500).json({ error: "Failed to generate suggestions" });
    }
  });

  app.patch("/api/learning-path/:id/progress", async (req, res) => {
    const id = parseInt(req.params.id);
    const { progress } = req.body;
    if (typeof progress !== "number") {
      return res.status(400).json({ error: "Invalid progress value" });
    }
    try {
      const path = await storage.updateLearningProgress(id, progress);
      res.json(path);
    } catch (error) {
      res.status(404).json({ error: "Learning path not found" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}